from graphx.graph import *
from graphx.algorithm import *
from graphx.draw_graph import *
from graphx.preprocessor import *


def main():
    print('Hello,welcome!')
    print('author: York Chu')

if __name__ == "__main__":
    main()